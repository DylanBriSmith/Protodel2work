package resultPackage;

public class Result {
    private String resultdata;
    public Result() {
    }

    public String getResultData() {
        return this.resultdata;
    }

    public void setResult(String result) {
        this.resultdata = resultdata;
    }



}
