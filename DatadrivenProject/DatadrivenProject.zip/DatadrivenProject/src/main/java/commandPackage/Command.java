package commandPackage;

import resultPackage.Result;

public class Command {
    public Command() {
    }

    public Result doAction() {
        return null;
    }
}

