package analysis;

import java.util.ArrayList;

interface Analysis {


        public  void doAnalysis(UserSelection userSelection);
        public String getAnalysisName();
        public void doComputations();


}


