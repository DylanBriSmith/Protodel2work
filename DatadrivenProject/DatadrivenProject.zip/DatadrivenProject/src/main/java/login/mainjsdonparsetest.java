package login;

public class mainjsdonparsetest {
    public static void main(String[] args) {
        UserData userd = new UserData();
        System.out.println(userd.getUserData());
    }
}
